package com.example.evatiendadeportes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.Model.Categoria
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import com.example.evatiendadeportes.R
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaCatalogo(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // MENU COMPLETO AQUÍ
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                MenuLateral(viewModel, navController, drawerState)
            }
        }
    ) {

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Catálogo de Productos") },
                    navigationIcon = {
                        IconButton(onClick = {
                            scope.launch { drawerState.open() }
                        }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menú")
                        }
                    }
                )
            }
        ) { padding ->
            PantallaCatalogoContenido(
                viewModel = viewModel,
                modifier = Modifier.padding(padding)
            )
        }
    }
}

@Composable
fun MenuLateral(viewModel: ProductoViewModel, navController: NavController, drawerState: DrawerState) {
    val scope = rememberCoroutineScope()

    ModalDrawerSheet {

        Spacer(Modifier.height(32.dp))

        Text(
            text = "Menú",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(16.dp))

        NavigationDrawerItem(
            label = { Text("Catálogo") },
            selected = false,
            onClick = {
                navController.navigate("catalogo") { launchSingleTop = true }
                scope.launch { drawerState.close() }
            }
        )

        NavigationDrawerItem(
            label = { Text("Carrito") },
            selected = false,
            onClick = {
                navController.navigate("carrito") { launchSingleTop = true }
                scope.launch { drawerState.close() }
            }
        )

        NavigationDrawerItem(
            label = { Text("Quiénes Somos") },
            selected = false,
            onClick = {
                navController.navigate("quienes_somos") { launchSingleTop = true }
                scope.launch { drawerState.close() }
            }
        )

        if (viewModel.esAdministrador()) {
            NavigationDrawerItem(
                label = { Text("Panel Admin") },
                selected = false,
                onClick = {
                    navController.navigate("admin") { launchSingleTop = true }
                    scope.launch { drawerState.close() }
                }
            )
        }

        Spacer(Modifier.height(24.dp))

        NavigationDrawerItem(
            label = { Text("Cerrar Sesión") },
            selected = false,
            onClick = {
                viewModel.cerrarSesion()
                navController.navigate("inicio_sesion") {
                    popUpTo(0)
                    launchSingleTop = true
                }
                scope.launch { drawerState.close() }
            }
        )
    }
}

@Composable
fun PantallaCatalogoContenido(
    viewModel: ProductoViewModel,
    modifier: Modifier = Modifier
) {
    Surface(modifier = modifier.fillMaxSize()) {

        LazyColumn(modifier = Modifier.padding(16.dp)) {

            item { Spacer(Modifier.height(16.dp)) }

            Categoria.values().forEach { categoria ->

                item {
                    Text(
                        categoria.name,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(8.dp))
                }

                val productos = viewModel.productosPorCategoria(categoria)

                items(productos) { producto ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(modifier = Modifier.padding(16.dp)) {

                            Image(
                                painter = painterResource(id = R.drawable.gato),
                                contentDescription = "Imagen del producto",
                                modifier = Modifier
                                    .size(80.dp)
                                    .padding(end = 12.dp)
                            )

                            Column(modifier = Modifier.weight(1f)) {

                                Text(
                                    producto.nombre,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(producto.descripcion)
                                Text("Precio: $${producto.precio}")

                                Spacer(Modifier.height(8.dp))

                                Button(onClick = {
                                    viewModel.agregarAlCarrito(producto.id)
                                }) {
                                    Text("Agregar al carrito")
                                }
                            }
                        }
                    }
                }

                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}
