package com.example.evatiendadeportes.ui.theme

import androidx.compose.ui.graphics.Color

val NegroFondo = Color(0xFF111111)
val GrisSuave = Color(0xFF1E1E1E)
val GrisTexto = Color(0xFFDDDDDD)
val AmarilloRockstar = Color(0xFFFFD200)
val AmarilloOscuro = Color(0xFFC6A300)
val RojoSangre = Color(0xFFA1121F
)
val RojoSangreOscuro = Color(0xFF8A0F1A
)
val NaranjaError = Color(0xFFDE0000)
