package com.example.evatiendadeportes.Model


enum class Categoria {
    SKATE, ROLLER, BMX
}