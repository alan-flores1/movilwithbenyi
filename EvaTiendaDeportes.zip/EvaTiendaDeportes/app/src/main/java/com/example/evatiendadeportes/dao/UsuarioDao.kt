package com.example.evatiendadeportes.dao
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.Model.Usuario
import com.example.evatiendadeportes.remote.ApiMovil
import com.example.evatiendadeportes.remote.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.jvm.java

class MovilDao {

    private val api = RetrofitClient.instance.create(ApiMovil::class.java)

    fun getUsuarios(callback: (List<Usuario>?) -> Unit) {
        api.getUsuarios().enqueue(object : Callback<List<Usuario>> {
            override fun onResponse(call: Call<List<Usuario>>, response: Response<List<Usuario>>) {
                callback(response.body())
            }

            override fun onFailure(call: Call<List<Usuario>>, t: Throwable) {
                callback(null)
            }
        })
    }

    fun getProductos(callback: (List<Producto>?) -> Unit) {
        api.getProductos().enqueue(object : Callback<List<Producto>> {
            override fun onResponse(call: Call<List<Producto>>, response: Response<List<Producto>>) {
                callback(response.body())
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                callback(null)
            }
        })
    }
}

