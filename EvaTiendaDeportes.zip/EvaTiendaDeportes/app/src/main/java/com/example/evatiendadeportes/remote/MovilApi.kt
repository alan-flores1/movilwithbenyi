
package com.example.evatiendadeportes.remote

import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.Model.Usuario
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.Call

interface ApiMovil {

    @GET("users")
    fun getUsuarios(): Call<List<Usuario>>

    @GET("users/{id}")
    fun getUsuario(@Path("id") id: Long): Call<Usuario>

    @POST("users")
    fun crearUsuario(@Body usuario: Usuario): Call<Usuario>

    @PUT("users/{id}")
    fun actualizarUsuario(@Path("id") id: Long, @Body usuario: Usuario): Call<Usuario>

    @DELETE("users/{id}")
    fun borrarUsuario(@Path("id") id: Long): Call<Void>


    @GET("api/productos")
    fun getProductos(): Call<List<Producto>>

    @GET("api/productos/{id}")
    fun getProducto(@Path("id") id: Long): Call<Producto>

    @POST("api/productos")
    fun crearProducto(@Body producto: Producto): Call<Producto>

    @PUT("api/productos/{id}")
    fun actualizarProducto(@Path("id") id: Long, @Body producto: Producto): Call<Producto>

    @DELETE("api/productos/{id}")
    fun borrarProducto(@Path("id") id: Long): Call<Void>
}

