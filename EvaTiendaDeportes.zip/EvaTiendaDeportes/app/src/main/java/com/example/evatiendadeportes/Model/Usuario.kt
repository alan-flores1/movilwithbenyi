package com.example.evatiendadeportes.Model


// Rol que puede tener un usuario
// Rol del usuario: Administrador o Cliente
enum class Rol { ADMINISTRADOR, CLIENTE }

// Representación de usuario
data class Usuario(
    val id: Long? = null,
    val nombre_user: String,
    val contrasenia: String,
    val rol: Rol = Rol.CLIENTE
)