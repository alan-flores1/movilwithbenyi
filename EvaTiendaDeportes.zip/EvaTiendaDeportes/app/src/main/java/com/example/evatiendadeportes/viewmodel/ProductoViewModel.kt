package com.example.evatiendadeportes.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.evatiendadeportes.Model.Categoria
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.Model.Rol
import com.example.evatiendadeportes.Model.Usuario

data class ItemCarrito(val producto: Producto, var cantidad: Int = 1) {
    val subtotal: Double get() = producto.precio * cantidad
}

class ProductoViewModel : ViewModel() {

    // ----------------- Estados -----------------
    private val _productos = mutableStateListOf<Producto>()
    val productos: List<Producto> get() = _productos

    val carrito = mutableStateListOf<ItemCarrito>()

    private val usuarios = mutableListOf<Usuario>()

    var usuarioActual = mutableStateOf<Usuario?>(null)
    var mensaje = mutableStateOf<String?>(null)
    var mensajeRapido = mutableStateOf<String?>(null)

    var productoMostrado = mutableStateOf<Producto?>(null)

    private var proximoIdProducto = 1

    init {
        usuarios.add(Usuario(id = null, nombre_user = "admin", contrasenia = "admin123", rol = Rol.ADMINISTRADOR))
        usuarios.add(Usuario(id = null, nombre_user = "cliente", contrasenia = "cliente123", rol = Rol.CLIENTE))

        // Productos iniciales
        cargarProductosIniciales()
    }

    // ----------------- Autenticación -----------------

    fun iniciarSesion(nombreUsuario: String, contrasena: String): Boolean {
        val usuario = usuarios.find { it.nombre_user == nombreUsuario && it.contrasenia == contrasena }
        return if (usuario != null) {
            usuarioActual.value = usuario
            mensaje.value = null
            true
        } else {
            mensaje.value = "Usuario o contraseña incorrectos"
            false
        }
    }

    fun registrarUsuario(nombreUsuario: String, contrasena: String, rol: Rol = Rol.CLIENTE): Boolean {
        if (nombreUsuario.isBlank() || contrasena.isBlank()) {
            mensaje.value = "Nombre de usuario y contraseña son obligatorios"
            return false
        }
        if (usuarios.any { it.nombre_user.equals(nombreUsuario, ignoreCase = true) }) {
            mensaje.value = "El usuario ya existe"
            return false
        }

        usuarios.add(
            Usuario(
                id = null,
                nombre_user = nombreUsuario.trim(),
                contrasenia = contrasena,
                rol = rol
            )
        )

        mensaje.value = "Usuario registrado correctamente"
        return true
    }

    fun cerrarSesion() {
        usuarioActual.value = null
        carrito.clear()
        mensaje.value = "Sesión cerrada"
    }

    fun esAdministrador(): Boolean = usuarioActual.value?.rol == Rol.ADMINISTRADOR

    // ----------------- Productos -----------------

    private fun cargarProductosIniciales() {
        if (_productos.isNotEmpty()) return

        agregarProductoInterno("Ramp Master Skate", 89990.0, "Skate deck profesional 8.0 pulgadas", Categoria.SKATE)
        agregarProductoInterno("Street Cruiser Skate", 75500.0, "Skate urbano resistente al desgaste", Categoria.SKATE)
        agregarProductoInterno("Turbo Roller", 120000.0, "Patines con ruedas de PU", Categoria.ROLLER)
        agregarProductoInterno("Speed Roller", 99000.0, "Patín inline cómodo", Categoria.ROLLER)
        agregarProductoInterno("BMX Freestyle X", 45000.0, "Bicicleta BMX para trucos", Categoria.BMX)
        agregarProductoInterno("BMX Street Pro", 52000.0, "Cuadro reforzado para saltos", Categoria.BMX)
    }

    private fun agregarProductoInterno(nombre: String, precio: Double, descripcion: String, categoria: Categoria) {
        _productos.add(Producto(proximoIdProducto++, nombre, precio, descripcion, categoria))
    }

    fun crearProducto(nombre: String, precio: Double?, descripcion: String, categoria: Categoria?): Boolean {
        if (!esAdministrador()) {
            mensaje.value = "Solo el administrador puede crear productos"
            return false
        }
        if (nombre.isBlank() || descripcion.isBlank() || precio == null || precio <= 0.0 || categoria == null) {
            mensaje.value = "Datos inválidos al crear producto"
            return false
        }
        _productos.add(Producto(proximoIdProducto++, nombre.trim(), precio, descripcion.trim(), categoria))
        mensaje.value = "Producto creado correctamente"
        return true
    }

    fun modificarProducto(id: Int, nombre: String, precio: Double?, descripcion: String, categoria: Categoria?): Boolean {
        if (!esAdministrador()) {
            mensaje.value = "Solo el administrador puede modificar productos"
            return false
        }

        val indice = _productos.indexOfFirst { it.id == id }
        if (indice == -1) {
            mensaje.value = "Producto no encontrado"
            return false
        }

        if (nombre.isBlank() || descripcion.isBlank() || precio == null || precio <= 0.0 || categoria == null) {
            mensaje.value = "Datos inválidos"
            return false
        }

        _productos[indice] = Producto(id, nombre.trim(), precio, descripcion.trim(), categoria)
        mensaje.value = "Producto modificado correctamente"
        return true
    }

    fun eliminarProducto(id: Int): Boolean {
        if (!esAdministrador()) {
            mensaje.value = "Solo el administrador puede eliminar productos"
            return false
        }

        val eliminado = _productos.removeIf { it.id == id }
        mensaje.value = if (eliminado) "Producto eliminado" else "Producto no encontrado"
        return eliminado
    }

    fun productosPorCategoria(categoria: Categoria): List<Producto> =
        _productos.filter { it.categoria == categoria }

    fun buscarProductoPorId(id: Int): Producto? =
        _productos.firstOrNull { it.id == id }

    // ----------------- Carrito -----------------

    fun agregarAlCarrito(idProducto: Int, cantidad: Int = 1) {
        val producto = buscarProductoPorId(idProducto) ?: return
        val index = carrito.indexOfFirst { it.producto.id == idProducto }

        if (index != -1) {
            val item = carrito[index]
            val nuevaCantidad = item.cantidad + cantidad
            carrito[index] = item.copy(cantidad = nuevaCantidad)
        } else {
            carrito.add(ItemCarrito(producto, cantidad.coerceAtLeast(1)))
        }

        mensajeRapido.value = "Producto agregado al carrito"
        productoMostrado.value = producto
    }

    fun eliminarDelCarrito(idProducto: Int) {
        carrito.removeIf { it.producto.id == idProducto }
    }

    fun cambiarCantidad(idProducto: Int, delta: Int) {
        val index = carrito.indexOfFirst { it.producto.id == idProducto }
        if (index == -1) return

        val item = carrito[index]
        val nuevaCantidad = item.cantidad + delta

        if (nuevaCantidad <= 0) {
            carrito.removeAt(index)
        } else {
            carrito[index] = item.copy(cantidad = nuevaCantidad)
        }
    }

    fun totalCarrito(): Double = carrito.sumOf { it.subtotal }

    fun vaciarCarrito() {
        carrito.clear()
    }

    fun carritoVacio(): Boolean = carrito.isEmpty()
}
