package com.example.miapp.model;

public enum Rol {
    ADMINISTRADOR,
    CLIENTE
}