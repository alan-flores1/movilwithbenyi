package com.example.miapp.model;

public enum Categoria {
    SKATE,
    ROLLER,
    BMX
}
