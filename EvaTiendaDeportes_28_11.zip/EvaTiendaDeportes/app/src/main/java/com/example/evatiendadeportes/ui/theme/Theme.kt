package com.example.evatiendadeportes.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext


private val ColoresOscuros = darkColorScheme(
    primary = CafePrincipal,
    onPrimary = Color.White,
    secondary = CafeSuaveDark,
    background = NegroFondo,
    surface = GrisSuave,
    onBackground = GrisTexto,
    onSurface = GrisTexto,
    outline = CafeOscuro,
    error = RojoError
)
private val ColoresClaros = lightColorScheme(
    primary = CafeOscuro,
    onPrimary = Color.Black,
    secondary = CafeSuave,
    background = Color(0xFFF5F5F5),
    surface = Color.White,
    onBackground = Color.Black,
    onSurface = Color.Black,
    outline = CafeOscuro,
    error = RojoError
)

@Composable
fun EvaTiendaDeportesTheme(
    oscuro: Boolean = isSystemInDarkTheme(),
    dinamico: Boolean = false,
    contenido: @Composable () -> Unit
) {
    val colores = when {
        dinamico && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val ctx = LocalContext.current
            if (oscuro) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        oscuro -> ColoresOscuros
        else -> ColoresClaros
    }

    MaterialTheme(
        colorScheme = colores,
        typography = Typography,
        content = contenido
    )
}
