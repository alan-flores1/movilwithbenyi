package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import kotlinx.coroutines.launch

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun PantallaCarrito(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val carrito = viewModel.carrito
    val total by remember { derivedStateOf { viewModel.totalCarrito() } }
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                MenuLateral(viewModel, navController, drawerState)
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Carrito de compras") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menú")
                        }
                    }
                )
            }
        ) { padding ->
            Surface(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier
                    .padding(padding) // ← añade el padding del Scaffold
                    .padding(16.dp)   // ← mantén tu margen interno
                ) {
                    Spacer(Modifier.height(12.dp))

                    if (carrito.isEmpty()) {
                        Text("Tu carrito está vacío.")
                    } else {

                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(carrito) { item ->

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                ) {
                                    Column(Modifier.padding(12.dp)) {

                                        Text(
                                            item.producto.nombre,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text("Precio: $${item.producto.precio}")
                                        Spacer(Modifier.height(4.dp))
                                        Text("Subtotal: $${item.subtotal}")

                                        Spacer(Modifier.height(8.dp))

                                        Row(
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {

                                            // Botones + y -
                                            Row {

                                                FilledTonalButton(
                                                    onClick = {
                                                        viewModel.cambiarCantidad(
                                                            item.producto.id,
                                                            -1
                                                        )
                                                    },
                                                    colors = ButtonDefaults.filledTonalButtonColors(
                                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                                    ),
                                                    contentPadding = PaddingValues(0.dp),
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Text(
                                                        "-",
                                                        style = MaterialTheme.typography.titleMedium
                                                    )
                                                }

                                                Spacer(Modifier.width(8.dp))

                                                Text("${item.cantidad}")

                                                Spacer(Modifier.width(8.dp))

                                                FilledTonalButton(
                                                    onClick = {
                                                        viewModel.cambiarCantidad(
                                                            item.producto.id,
                                                            1
                                                        )
                                                    },
                                                    colors = ButtonDefaults.filledTonalButtonColors(
                                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                                    ),
                                                    contentPadding = PaddingValues(0.dp),
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Text(
                                                        "+",
                                                        style = MaterialTheme.typography.titleMedium
                                                    )
                                                }
                                            }

                                            // Botón eliminar fuera del row de +/-
                                            Button(
                                                onClick = { viewModel.eliminarDelCarrito(item.producto.id) }
                                            ) {
                                                Text("Eliminar")
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(16.dp))

                        Text(
                            "Total: $${"%.2f".format(total)}",
                            style = MaterialTheme.typography.titleLarge
                        )

                        Spacer(Modifier.height(8.dp))

                        Button(
                            onClick = { viewModel.vaciarCarrito() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Vaciar Carrito")
                        }
                    }
                }
            }
        }
    }
}
