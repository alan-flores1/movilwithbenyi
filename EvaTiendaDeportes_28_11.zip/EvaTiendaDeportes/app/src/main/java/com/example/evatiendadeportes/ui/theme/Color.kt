package com.example.evatiendadeportes.ui.theme

import androidx.compose.ui.graphics.Color

// PALETA MODO CLARO
val BlancoFondo = Color(0xFFFFFFFF)
val NegroTexto = Color(0xFF000000)

// Café principal
val CafePrincipal = Color(0xA6D06A2C)

// Tonos complementarios
val CafeOscuro = Color(0xFF7A2F00)
val CafeSuave = Color(0xFFF2D3BF)

// Amarillos cálidos
val AmarilloRockstar = Color(0xFFFFD200)
val AmarilloOscuro = Color(0xFFC6A300)

// Colores de error reemplazando rojo por naranja/café
val RojoError = Color.Red
val NaranjaErrorOscuro = Color(0xFFB55800)


// PALETA MODO OSCURO
val NegroFondo = Color(0xFF111111)
val GrisSuave = Color(0xFF1E1E1E)
val GrisTexto = Color(0xFFDDDDDD)

// Café oscuro para modo oscuro
val CafePrincipalDark = Color(0xFF8A3A00)
val CafeOscuroDark = Color(0xFF5E2600)
val CafeSuaveDark = Color(0xFFB8743A)

// Amarillos compatibles
val AmarilloRockstarDark = Color(0xFFFFD200)
val AmarilloOscuroDark = Color(0xFFC6A300)

// Error en naranja oscuro
val NaranjaErrorDark = Color(0xFFCC5E00)
val NaranjaErrorOscuroDark = Color(0xFF9C4700)