package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuLateral(
    viewModel: ProductoViewModel,
    navController: NavController,
    content: @Composable () -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val usuario = viewModel.usuarioActual.value
    val c = MaterialTheme.colorScheme

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = c.primary,   // FONDO ROJO
                drawerContentColor = Color.White    // TEXTO BLANCO
            ) {

                Spacer(Modifier.height(16.dp))

                NavigationDrawerItem(
                    label = { Text("Catálogo") },
                    selected = false,
                    onClick = {
                        navController.navigate("catalogo")
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.secondary, // rojo oscuro
                        selectedTextColor = Color.White,
                        selectedIconColor = Color.White
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Carrito") },
                    selected = false,
                    onClick = {
                        navController.navigate("carrito")
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.secondary,
                        selectedTextColor = Color.White,
                        selectedIconColor = Color.White
                    )
                )

                if (viewModel.esAdministrador()) {
                    NavigationDrawerItem(
                        label = { Text("Administración") },
                        selected = false,
                        onClick = {
                            navController.navigate("admin")
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            unselectedContainerColor = Color.Transparent,
                            unselectedTextColor = Color.White,
                            unselectedIconColor = Color.White,
                            selectedContainerColor = c.secondary,
                            selectedTextColor = Color.White,
                            selectedIconColor = Color.White
                        )
                    )
                }

                NavigationDrawerItem(
                    label = { Text("Cerrar Sesión") },
                    selected = false,
                    onClick = {
                        viewModel.cerrarSesion()
                        navController.navigate("inicio_sesion") {
                            popUpTo(0)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.error,    // rojo error
                        selectedTextColor = Color.White,
                        selectedIconColor = Color.White
                    )
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Bienvenido, ${usuario?.nombre_user ?: ""}") },
                    navigationIcon = {
                        IconButton(onClick = {
                            scope.launch { drawerState.open() }
                        }) {
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = null,
                                tint = Color.White          // MENU BLANCO
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = c.primary,       // BARRA ROJA
                        titleContentColor = Color.White
                    )
                )
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                content()
            }
        }
    }
}
