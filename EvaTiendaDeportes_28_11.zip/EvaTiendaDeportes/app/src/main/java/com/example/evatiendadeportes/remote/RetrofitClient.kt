    package com.example.evatiendadeportes.remote

    import retrofit2.Retrofit
    import retrofit2.converter.gson.GsonConverterFactory

    object RetrofitClient {

        private const val BASE_URL = "https://musicapi01-production.up.railway.app/api/"
        // Cambia por tu IP LOCAL o dominio

        val instance: Retrofit by lazy {
            Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        val api: ApiMovil by lazy {
            instance.create(ApiMovil::class.java)
        }

    }