package com.example.miapp.config;

import com.example.miapp.model.Producto;
import com.example.miapp.model.User;
import com.example.miapp.repository.ProductoRepository;
import com.example.miapp.repository.UserRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner loadData(ProductoRepository productoRepository, UserRepository userRepository) {
        return args -> {

            // ===================== USUARIOS =====================
            if (userRepository.count() == 0) {

                userRepository.save(new User(
                        null,
                        "admin",
                        "admin123",
                        User.Rol.ADMIN
                ));

                userRepository.save(new User(
                        null,
                        "cliente",
                        "cliente123",
                        User.Rol.CLIENTE
                ));

                System.out.println("Usuarios cargados.");
            } else {
                System.out.println("Usuarios existentes, no se agregan.");
            }

            // ===================== PRODUCTOS =====================
            if (productoRepository.count() == 0) {

                String imgBlanca = "/img/white.png";

                // ------- SKATE -------
                productoRepository.save(new Producto(
                        null,
                        "Ramp Master Skate",
                        89990.0,
                        "Skate deck profesional 8.0 pulgadas",
                        imgBlanca,
                        Producto.Categoria.SKATE
                ));

                productoRepository.save(new Producto(
                        null,
                        "Street Cruiser Skate",
                        75500.0,
                        "Skate urbano resistente al desgaste",
                        imgBlanca,
                        Producto.Categoria.SKATE
                ));

                // ------- ROLLER -------
                productoRepository.save(new Producto(
                        null,
                        "Turbo Roller",
                        120000.0,
                        "Patines con ruedas de PU",
                        imgBlanca,
                        Producto.Categoria.ROLLER
                ));

                productoRepository.save(new Producto(
                        null,
                        "Speed Roller",
                        99000.0,
                        "Patín inline cómodo",
                        imgBlanca,
                        Producto.Categoria.ROLLER
                ));

                // ------- BMX -------
                productoRepository.save(new Producto(
                        null,
                        "BMX Freestyle X",
                        45000.0,
                        "Bicicleta BMX para trucos",
                        imgBlanca,
                        Producto.Categoria.BMX
                ));

                productoRepository.save(new Producto(
                        null,
                        "BMX Street Pro",
                        52000.0,
                        "Cuadro reforzado para saltos",
                        imgBlanca,
                        Producto.Categoria.BMX
                ));

                System.out.println("Productos cargados.");
            } else {
                System.out.println("Productos existentes, no se agregan.");
            }
        };
    }
}