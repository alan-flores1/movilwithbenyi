package com.example.miapp.controller;

import com.example.miapp.model.Carrito;
import com.example.miapp.model.Producto;
import com.example.miapp.model.User;
import com.example.miapp.repository.CarritoRepository;
import com.example.miapp.repository.ProductoRepository;
import com.example.miapp.repository.UserRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/carrito")
@CrossOrigin(origins = "*")
public class CarritoController {

    private final CarritoRepository carritoRepository;
    private final UserRepository userRepository;
    private final ProductoRepository prodRepository;

    public CarritoController(CarritoRepository carritoRepository,
                             UserRepository userRepository,
                             ProductoRepository prodRepository) {
        this.carritoRepository = carritoRepository;
        this.userRepository = userRepository;
        this.prodRepository = prodRepository;
    }

    @PostMapping("/crear/{userId}")
    public ResponseEntity<Carrito> crearCarrito(@PathVariable Long userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Carrito carrito = new Carrito();
        carrito.setUser(user);

        return ResponseEntity.ok(carritoRepository.save(carrito));
    }

    @PostMapping("/{carritoId}/agregar/{productoId}")
    public ResponseEntity<Carrito> agregarProducto(
            @PathVariable Long carritoId,
            @PathVariable Long productoId) {

        Carrito carrito = carritoRepository.findById(carritoId)
                .orElseThrow(() -> new RuntimeException("Carrito no encontrado"));

        Producto producto = prodRepository.findById(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        carrito.getProductos().add(producto);

        return ResponseEntity.ok(carritoRepository.save(carrito));
    }

    @GetMapping("/{carritoId}")
    public ResponseEntity<List<Producto>> verProductos(@PathVariable Long carritoId) {

        Carrito carrito = carritoRepository.findById(carritoId)
                .orElseThrow(() -> new RuntimeException("Carrito no encontrado"));

        return ResponseEntity.ok(carrito.getProductos());
    }

    @DeleteMapping("/{carritoId}/vaciar")
    public ResponseEntity<Void> vaciarCarrito(@PathVariable Long carritoId) {

        Carrito carrito = carritoRepository.findById(carritoId)
                .orElseThrow(() -> new RuntimeException("Carrito no encontrado"));

        carrito.getProductos().clear();
        carritoRepository.save(carrito);

        return ResponseEntity.noContent().build();
    }
}