package com.example.miapp.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.example.miapp.model.Producto;
import com.example.miapp.repository.ProdRepository;

import jakarta.persistence.Table;

@Table(name = "productos")
@RestController
@RequestMapping("/api/productos")
@CrossOrigin(origins = "*") // Permite peticiones desde frontend
public class ProdController {

    private final ProdRepository prodRepository;

    public ProdController(ProdRepository prodRepository) {
        this.prodRepository = prodRepository;
    }

    // Obtener todos los libros
    @GetMapping
    public List<Producto> getAllBooks() {
        return prodRepository.findAll();
    }

    // Obtener libro por ID
    @GetMapping("/{id}")
    public Producto getBookById(@PathVariable Long id) {
        return prodRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));
    }

    // Crear un nuevo libro
    @PostMapping
    public Producto createBook(@RequestBody Producto prod) {
        return prodRepository.save(prod);
    }

    // Actualizar libro existente
    @PutMapping("/{id}")
    public Producto updateBook(@PathVariable Long id, @RequestBody Producto prodDetails) {
        Producto prod = prodRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));

        prod.setNombre(prodDetails.getNombre());
        prod.setPrecio(prodDetails.getPrecio());
        prod.setCategoria(prodDetails.getCategoria());
        return prodRepository.save(prod);
    }

    // Eliminar libro
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        prodRepository.deleteById(id);
    }
}
